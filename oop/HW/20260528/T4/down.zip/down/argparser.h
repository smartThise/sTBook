#pragma once
#include "flagargument.h"
#include "valueargument.h"

#include <memory>
#include <map>
#include <iostream>

class ArgParser {
private:
    std::string program_description_;
    std::vector<std::unique_ptr<IArgument>> arguments_;
    std::map<std::string, IArgument*> long_name_map_;
    std::map<char, IArgument*> short_name_map_;
    bool help_wanted_ = false;

public:
    ArgParser(const std::string& description) : program_description_(description) {
        addFlag('h', "help", "Show this help message.");
    }

    void addFlag(char s, const std::string& l, const std::string& d) {
        // do something
    }
    template<typename T>
    void addValue(char s, const std::string& l, const std::string& d, T def_val) {
        // do something
    }
    bool parse(int argc, char* argv[]) {
        // do something
    }
    template<typename T>
    std::optional<T> get(const std::string& name) const {
        // do something
    }

    bool wantsHelp() const { return help_wanted_; }
    void printHelp() const {
        std::cout << program_description_ << "\n\nUsage:\n";
        for (const auto& arg : arguments_) {
            std::cout << arg->get_info() << std::endl;
        }
    }
};