#pragma once
#include "iargument.h"

template<typename T>
class ValueArgument : public IArgument {
public:
    std::optional<T> value;
    T default_value;
    ValueArgument(char s, const std::string& l, const std::string& d, T def_val) {
        // do something
    }
    bool parse(const std::vector<std::string>&, size_t&) override {
        // do something
    }
    std::string get_info() const override {
        // do something
    }
};