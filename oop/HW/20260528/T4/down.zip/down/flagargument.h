#pragma once
#include "iargument.h"

class FlagArgument : public IArgument {
public:
    bool value = false;
    FlagArgument(char s, const std::string& l, const std::string& d) {
        // do something
    }
    bool parse(const std::vector<std::string>&, size_t&) override {
        // do something
    }
    std::string get_info() const override {
        // do something
    }
    bool is_flag() const override {
        // do something
    }
};