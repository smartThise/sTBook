#ifndef MY_LIB_H
#define MY_LIB_H

#include <iostream>

void print();

void print(int x);

void print(bool x);

void print(std::string s = "");

void print(char c);

auto input();

class Array {
    int size{};
    int a[100]{};
public:
    void append(int x);

    void pop();

    int getSize();
};

void print(Array a);

#endif
